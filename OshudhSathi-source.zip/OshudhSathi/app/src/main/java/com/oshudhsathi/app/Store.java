package com.oshudhsathi.app;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import java.time.*;
import java.util.*;
final class Store extends SQLiteOpenHelper {
 Store(Context c) { super(c.getApplicationContext(),"sathi.db",null,1); }
 public void onCreate(SQLiteDatabase db) {
  db.execSQL("CREATE TABLE meds(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,amount TEXT NOT NULL,times TEXT NOT NULL,start TEXT NOT NULL,end TEXT NOT NULL,note TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1)");
  db.execSQL("CREATE TABLE doses(id INTEGER PRIMARY KEY AUTOINCREMENT,med INTEGER NOT NULL,name TEXT NOT NULL,amount TEXT NOT NULL,note TEXT NOT NULL,slot TEXT NOT NULL,day TEXT NOT NULL,due INTEGER NOT NULL,notify_at INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending',taken_at INTEGER NOT NULL DEFAULT 0,UNIQUE(med,slot,day))");
 }
 public void onUpgrade(SQLiteDatabase db,int old,int next) { throw new IllegalStateException("Unsupported schema upgrade"); }
 static final class Med { long id; String name,amount,times,start,end,note; }
 static final class Dose { long id,med,due,notifyAt,takenAt; String name,amount,note,slot,day,status; }
 List<Med> meds() { ArrayList<Med> out=new ArrayList<>(); try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM meds WHERE active=1 ORDER BY name",null)) { while(c.moveToNext()) { Med m=new Med(); m.id=c.getLong(0);m.name=c.getString(1);m.amount=c.getString(2);m.times=c.getString(3);m.start=c.getString(4);m.end=c.getString(5);m.note=c.getString(6);out.add(m); } } return out; }
 long add(String name,String amount,String times,String start,String end,String note) { ContentValues v=new ContentValues();v.put("name",name);v.put("amount",amount);v.put("times",times);v.put("start",start);v.put("end",end);v.put("note",note);return getWritableDatabase().insertOrThrow("meds",null,v); }
 long ensure(Med m,LocalDate day,String slot) {
  long due=TimeRules.at(day,slot,ZoneId.systemDefault()); ContentValues v=new ContentValues();v.put("med",m.id);v.put("name",m.name);v.put("amount",m.amount);v.put("note",m.note);v.put("slot",slot);v.put("day",day.toString());v.put("due",due);v.put("notify_at",due);
  getWritableDatabase().insertWithOnConflict("doses",null,v,SQLiteDatabase.CONFLICT_IGNORE);
  try(Cursor c=getReadableDatabase().rawQuery("SELECT id FROM doses WHERE med=? AND slot=? AND day=?",new String[]{""+m.id,slot,day.toString()})) { c.moveToFirst();return c.getLong(0); }
 }
 static Dose row(Cursor c) { Dose d=new Dose();d.id=c.getLong(0);d.med=c.getLong(1);d.name=c.getString(2);d.amount=c.getString(3);d.note=c.getString(4);d.slot=c.getString(5);d.day=c.getString(6);d.due=c.getLong(7);d.notifyAt=c.getLong(8);d.status=c.getString(9);d.takenAt=c.getLong(10);return d; }
 Dose dose(long id) { try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM doses WHERE id=?",new String[]{""+id})) { return c.moveToFirst()?row(c):null; } }
 List<Dose> doses(String day) { List<Dose> out=new ArrayList<>();String sql="SELECT * FROM doses"+(day==null?" ORDER BY due DESC LIMIT 200":" WHERE day=? ORDER BY due");try(Cursor c=getReadableDatabase().rawQuery(sql,day==null?null:new String[]{day})) {while(c.moveToNext())out.add(row(c));}return out; }
 List<Dose> pending() { List<Dose> out=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT doses.* FROM doses JOIN meds ON doses.med=meds.id WHERE doses.status='pending' AND meds.active=1",null)) {while(c.moveToNext())out.add(row(c));}return out; }
 boolean active(long id) {try(Cursor c=getReadableDatabase().rawQuery("SELECT active FROM meds WHERE id=?",new String[]{""+id})) { return c.moveToFirst()&&c.getInt(0)==1; }}
 boolean complete(long id,String status) {ContentValues v=new ContentValues();v.put("status",status);v.put("taken_at",System.currentTimeMillis());return getWritableDatabase().update("doses",v,"id=? AND status='pending'",new String[]{""+id})>0;}
 boolean snooze(long id,long at) {ContentValues v=new ContentValues();v.put("notify_at",at);return getWritableDatabase().update("doses",v,"id=? AND status='pending'",new String[]{""+id})>0;}
 void stop(long id) {ContentValues v=new ContentValues();v.put("active",0);getWritableDatabase().update("meds",v,"id=?",new String[]{""+id});ContentValues d=new ContentValues();d.put("status","stopped");getWritableDatabase().update("doses",d,"med=? AND status='pending'",new String[]{""+id});}
}
