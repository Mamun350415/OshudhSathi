package com.oshudhsathi.app;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
public final class TimeRules {
 private TimeRules() {}
 public static String normalize(String raw) {
  String s=raw.trim(); String bn="০১২৩৪৫৬৭৮৯";
  for(int i=0;i<10;i++) s=s.replace(bn.charAt(i),(char)('0'+i));
  return s;
 }
 public static String[] times(String raw) {
  TreeSet<String> out=new TreeSet<>();
  for(String part:normalize(raw).split(",",-1)) {
   if(!part.trim().matches("\\d{1,2}:\\d{2}")) throw new IllegalArgumentException("সময় লিখুন 08:00, 14:00, 22:00 এর মতো");
   String[] a=part.trim().split(":"); int h=Integer.parseInt(a[0]), m=Integer.parseInt(a[1]);
   if(h>23||m>59) throw new IllegalArgumentException("সময় 00:00 থেকে 23:59 এর মধ্যে দিন");
   out.add(String.format(Locale.ROOT,"%02d:%02d",h,m));
  }
  if(out.isEmpty()||out.size()>8) throw new IllegalArgumentException("দিনে ১ থেকে ৮টি সময় দিন");
  return out.toArray(new String[0]);
 }
 public static long at(LocalDate day,String time,ZoneId zone) { return day.atTime(LocalTime.parse(time)).atZone(zone).toInstant().toEpochMilli(); }
 public static String display(long millis) { return Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd MMM • HH:mm",new Locale("bn"))); }
 public static boolean inRange(LocalDate day,String start,String end) { return !day.isBefore(LocalDate.parse(start)) && (end.isEmpty()||!day.isAfter(LocalDate.parse(end))); }
}
