package com.oshudhsathi.app;
import android.app.*;
import android.content.*;
import android.os.Build;
public final class TestReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){ReminderReceiver.channel(c);NotificationManager n=c.getSystemService(NotificationManager.class);if(!n.areNotificationsEnabled()||(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED))return;if(c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED && Build.VERSION.SDK_INT>=33)return;n.notify("test",1,new Notification.Builder(c,ReminderReceiver.CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle("ওষুধ সাথী • পরীক্ষা সফল").setContentText("এটি শুধু রিমাইন্ডার পরীক্ষা। কোনো ওষুধ খেতে হবে না।").setAutoCancel(true).build());}
}
