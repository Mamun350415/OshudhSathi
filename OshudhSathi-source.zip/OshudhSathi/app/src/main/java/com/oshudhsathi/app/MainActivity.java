package com.oshudhsathi.app;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.time.*;
import java.util.*;
public final class MainActivity extends Activity {
 LinearLayout root,body; int ink,muted,card,bg; String page="today";
 final Handler handler=new Handler(Looper.getMainLooper());
 final Runnable tick=new Runnable(){public void run(){if("today".equals(page))render();handler.postDelayed(this,60000);}};
 public void onCreate(Bundle b) {super.onCreate(b);if(b!=null)page=b.getString("page","today");ReminderReceiver.channel(this);}
 public void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putString("page",page);}
 public void onResume(){super.onResume();Scheduler.refresh(this);render();handler.removeCallbacks(tick);handler.postDelayed(tick,60000);}
 public void onPause(){handler.removeCallbacks(tick);super.onPause();}
 int dp(int v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
 TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(ink);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(0,dp(5),0,dp(5));return t;}
 GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
 Button button(String label,Runnable run){Button b=new Button(this);b.setText(label);b.setTextSize(17);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackground(shape(Color.rgb(8,126,112),14));b.setPadding(dp(10),dp(8),dp(10),dp(8));b.setMinHeight(dp(52));b.setOnClickListener(v->run.run());return b;}
 void addButton(LinearLayout box,String label,Runnable run){Button b=button(label,run);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(10);box.addView(b,lp);}
 LinearLayout box(){LinearLayout x=new LinearLayout(this);x.setOrientation(1);x.setPadding(dp(16),dp(12),dp(16),dp(12));x.setBackground(shape(card,18));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(12);body.addView(x,lp);return x;}
 void render(){
  boolean dark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
  ink=Color.parseColor(dark?"#F0F7F5":"#143632");muted=Color.parseColor(dark?"#ABC1BB":"#55706A");card=Color.parseColor(dark?"#1B2B29":"#FFFFFF");bg=Color.parseColor(dark?"#101A1A":"#F3F7F6");
  root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(bg);setContentView(root);
  root.setOnApplyWindowInsetsListener((v,insets)->{if(Build.VERSION.SDK_INT>=30){android.graphics.Insets a=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());v.setPadding(a.left,a.top,a.right,a.bottom);}else{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());}return insets;});root.requestApplyInsets();
  LinearLayout head=new LinearLayout(this);head.setPadding(dp(20),dp(12),dp(16),dp(12));head.setGravity(Gravity.CENTER_VERTICAL);head.setBackgroundColor(Color.rgb(8,126,112));TextView title=text("✚  ওষুধ সাথী",26,true);title.setTextColor(Color.WHITE);head.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button help=button("সেটআপ",()->{page="setup";render();});head.addView(help);root.addView(head);
  LinearLayout nav=new LinearLayout(this);String[] labels={"আজ","ওষুধ","ইতিহাস"},pages={"today","meds","history"};for(int n=0;n<3;n++){final String dest=pages[n];TextView t=text(labels[n],18,page.equals(dest));t.setGravity(Gravity.CENTER);t.setPadding(0,dp(14),0,dp(14));if(page.equals(dest))t.setTextColor(Color.rgb(8,160,135));t.setOnClickListener(v->{page=dest;render();});nav.addView(t,new LinearLayout.LayoutParams(0,-2,1));}root.addView(nav);
  ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);body=new LinearLayout(this);body.setOrientation(1);body.setPadding(dp(18),dp(8),dp(18),dp(24));scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  switch(page){case "meds":meds();break;case "history":history();break;case "setup":setup();break;default:today();}
  if(!"setup".equals(page)){LinearLayout foot=new LinearLayout(this);foot.setPadding(dp(18),dp(8),dp(18),dp(12));addButton(foot,"＋ ওষুধ যোগ করুন",()->editor());root.addView(foot);}
 }
 void today(){
  body.addView(text(TimeRules.display(System.currentTimeMillis()).split(" • ")[0],20,true));
  if(!notifications()||!Scheduler.exact(this)){LinearLayout warn=box();warn.addView(text("রিমাইন্ডারের সেটআপ বাকি আছে",18,true));addButton(warn,"সেটআপ ঠিক করুন",()->{page="setup";render();});}
  try(Store s=new Store(this)){List<Store.Dose> rows=s.doses(LocalDate.now().toString());int taken=0;for(Store.Dose d:rows)if("taken".equals(d.status))taken++;body.addView(text("আজ খেয়েছেন "+taken+" / "+rows.size(),18,false));
   if(rows.isEmpty()){LinearLayout empty=box();empty.addView(text("আজ কোনো নির্ধারিত ওষুধ নেই",22,true));empty.addView(text("ওষুধের নাম ও চিকিৎসকের দেওয়া সময় যোগ করুন। আজকের সময় পেরিয়ে গেলে পরের দিন থেকে রিমাইন্ডার শুরু হবে।",17,false));}
   for(Store.Dose d:rows)doseCard(d,true);
  }
 }
 String status(Store.Dose d){switch(d.status){case "taken":return "✓ খেয়েছি • "+TimeRules.display(d.takenAt);case "skipped":return "বাদ দেওয়া হয়েছে";case "stopped":return "রিমাইন্ডার বন্ধ";default:if(d.notifyAt>d.due&&d.notifyAt>System.currentTimeMillis())return "পরে মনে করাবে • "+TimeRules.display(d.notifyAt);return d.due<System.currentTimeMillis()?"সময় পেরিয়েছে • খাওয়া নিশ্চিত করা হয়নি":"খাওয়া বাকি";}}
 void doseCard(Store.Dose d,boolean actions){LinearLayout x=box();x.addView(text(d.slot+"  •  "+d.name,21,true));x.addView(text(d.amount,18,false));if(!d.note.isEmpty())x.addView(text(d.note,16,false));TextView st=text(status(d),16,false);st.setTextColor(muted);x.addView(st);
  if(actions&&"pending".equals(d.status)){if(d.due>System.currentTimeMillis()){x.addView(text("নির্ধারিত সময় হলে খাওয়ার রেকর্ড যোগ করতে পারবেন।",15,false));return;}
   addButton(x,"খেয়েছি",()->new AlertDialog.Builder(this).setTitle("খেয়েছেন নিশ্চিত করুন").setMessage(d.name+" • "+d.amount+"\nসত্যিই খাওয়া হলে রেকর্ড করুন।").setNegativeButton("ফিরে যান",null).setPositiveButton("খেয়েছি",(a,b)->{try(Store s=new Store(this)){s.complete(d.id,"taken");}Scheduler.cancel(this,d.id);render();}).show());
   addButton(x,"১০ মিনিট পরে মনে করাও",()->{try(Store s=new Store(this)){if(s.snooze(d.id,System.currentTimeMillis()+600000)){Scheduler.cancel(this,d.id);Scheduler.schedule(this,s.dose(d.id));}}render();});
   TextView skip=text("খাইনি / বাদ দিয়েছি",16,false);skip.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("এইবারের রেকর্ড বাদ দেবেন?").setMessage("এটি ওষুধ বাদ দেওয়ার চিকিৎসা পরামর্শ নয়।").setNegativeButton("না",null).setPositiveButton("রেকর্ড করুন",(a,b)->{try(Store s=new Store(this)){s.complete(d.id,"skipped");}Scheduler.cancel(this,d.id);render();}).show());x.addView(skip);
  }
 }
 void meds(){try(Store s=new Store(this)){List<Store.Med> all=s.meds();if(all.isEmpty())body.addView(text("এখনও কোনো ওষুধ যোগ করেননি।",20,false));for(Store.Med m:all){LinearLayout x=box();x.addView(text(m.name,22,true));x.addView(text(m.amount+" • "+m.times,18,false));x.addView(text(m.end.isEmpty()?"শেষ তারিখ নির্ধারিত নয়":"শেষ দিন: "+m.end,16,false));if(!m.note.isEmpty())x.addView(text(m.note,16,false));addButton(x,"রিমাইন্ডার বন্ধ করুন",()->new AlertDialog.Builder(this).setTitle("রিমাইন্ডার বন্ধ করবেন?").setMessage("আগের খাওয়ার ইতিহাস থাকবে। চিকিৎসকের নির্দেশ ছাড়া ওষুধ বন্ধ করবেন না।").setNegativeButton("ফিরে যান",null).setPositiveButton("রিমাইন্ডার বন্ধ",(a,b)->{try(Store db=new Store(this)){for(Store.Dose d:db.pending())if(d.med==m.id)Scheduler.cancel(this,d.id);db.stop(m.id);}render();}).show());}}}
 void history(){body.addView(text("খাওয়ার রেকর্ড",22,true));body.addView(text("সর্বশেষ ২০০টি নির্ধারিত সময়। এটি আপনার দেওয়া রেকর্ড।",16,false));try(Store s=new Store(this)){boolean any=false;for(Store.Dose d:s.doses(null)){if(d.due>System.currentTimeMillis())continue;any=true;body.addView(text(TimeRules.display(d.due),16,true));doseCard(d,false);}if(!any)body.addView(text("এখনও কোনো ইতিহাস নেই।",18,false));}}
 boolean notifications(){NotificationManager nm=getSystemService(NotificationManager.class);NotificationChannel c=nm.getNotificationChannel(ReminderReceiver.CHANNEL);return nm.areNotificationsEnabled()&&(c==null||c.getImportance()!=NotificationManager.IMPORTANCE_NONE);}
 void open(Intent i){try{startActivity(i);}catch(ActivityNotFoundException e){Toast.makeText(this,"ফোনের Settings থেকে এই অনুমতি দিন।",Toast.LENGTH_LONG).show();}}
 void setup(){
  body.addView(text("রিমাইন্ডার প্রস্তুত করুন",24,true));
  LinearLayout x=box();x.addView(text(notifications()?"✓ নোটিফিকেশন চালু":"নোটিফিকেশন বন্ধ",20,true));addButton(x,"নোটিফিকেশন সেটিং",()->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},1);else open(new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()).putExtra(Settings.EXTRA_CHANNEL_ID,ReminderReceiver.CHANNEL));});
  x=box();x.addView(text(Scheduler.exact(this)?"✓ সময়মতো অ্যালার্ম অনুমোদিত":"সময়মতো অ্যালার্মের অনুমতি দিন",20,true));x.addView(text("অনুমতি না থাকলে রিমাইন্ডার দেরিতে আসতে পারে।",17,false));if(Build.VERSION.SDK_INT>=31)addButton(x,"অ্যালার্মের অনুমতি",()->open(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName()))));
  x=box();x.addView(text("ফোনের ব্যাটারি সেটিং",20,true));x.addView(text("রিমাইন্ডার দেরি হলে App battery usage-এ Unrestricted এবং ফোনে থাকলে Auto-start অনুমতি দিন। Force stop করলে আবার অ্যাপ খুলুন। নীরব মোড বা Do Not Disturb-এ শব্দ নাও হতে পারে।",17,false));addButton(x,"অ্যাপের ফোন সেটিং",()->open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))));
  x=box();x.addView(text("এক মিনিট পরে পরীক্ষা",20,true));x.addView(text("এটি একটি ডেমো নোটিফিকেশন; কোনো ওষুধ খাওয়ার নির্দেশ নয়। পরীক্ষাটি দিয়ে ফোন লক করেও যাচাই করুন।",17,false));addButton(x,"টেস্ট রিমাইন্ডার দিন",()->test());
  x=box();x.addView(text("আপনার তথ্য আপনার ফোনে",20,true));x.addView(text("ইন্টারনেট, অ্যাকাউন্ট, বিজ্ঞাপন বা সার্ভার নেই। ওষুধ ও ইতিহাস এই ফোনে সংরক্ষিত। অ্যাপ আনইনস্টল বা ডেটা মুছলে রেকর্ড মুছে যাবে।\n\nওষুধের নাম, পরিমাণ ও সময় চিকিৎসকের নির্দেশ অনুযায়ী লিখুন। অ্যাপ ডোজ নির্ধারণ করে না। আগের ডোজ নেওয়া হয়েছে কি না নিশ্চিত না হলে অ্যাপ দেখে অতিরিক্ত ডোজ নেবেন না।\n\nসংস্করণ 1.0.0",17,false));
 }
 void test(){if(!notifications()){Toast.makeText(this,"আগে নোটিফিকেশন চালু করুন",Toast.LENGTH_LONG).show();return;}Intent i=new Intent(this,TestReceiver.class).setAction("TEST");PendingIntent pi=PendingIntent.getBroadcast(this,999,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager a=getSystemService(AlarmManager.class);long at=System.currentTimeMillis()+60000;try{if(Scheduler.exact(this))a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);}catch(SecurityException e){a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);}Toast.makeText(this,"পরীক্ষা চালু হয়েছে; এখন ফোন লক করুন।",Toast.LENGTH_LONG).show();}
 EditText field(LinearLayout x,String label,String hint,int type){x.addView(text(label,17,true));EditText e=new EditText(this);e.setHint(hint);e.setTextSize(18);e.setInputType(type);x.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;}
 void editor(){
  LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(dp(22),dp(12),dp(22),dp(20));ScrollView scroll=new ScrollView(this);scroll.addView(form);
  EditText name=field(form,"ওষুধের নাম","যেমন: চিকিৎসকের দেওয়া নাম",1),amount=field(form,"নির্ধারিত পরিমাণ","যেমন: ১টি ট্যাবলেট — প্রেসক্রিপশন অনুযায়ী",1),times=field(form,"প্রতিদিনের সময় (২৪ ঘণ্টা)","08:00, 14:00, 22:00",1),days=field(form,"কত দিন চলবে","ফাঁকা রাখলে শেষ দিন থাকবে না",2),note=field(form,"নির্দেশনা (ঐচ্ছিক)","যেমন: প্রেসক্রিপশন অনুযায়ী খাবারের পরে",1);
  TextView error=text("",16,false);error.setTextColor(Color.rgb(190,55,55));form.addView(error);
  AlertDialog dialog=new AlertDialog.Builder(this).setTitle("ওষুধ যোগ করুন").setView(scroll).setNegativeButton("বাতিল",null).setPositiveButton("সংরক্ষণ",null).create();dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
   try{String n=name.getText().toString().trim(),a=amount.getText().toString().trim(),nt=note.getText().toString().trim();if(n.isEmpty()||a.isEmpty())throw new IllegalArgumentException("নাম ও নির্ধারিত পরিমাণ দিন");if(n.length()>100||a.length()>120||nt.length()>400)throw new IllegalArgumentException("নাম, পরিমাণ বা নির্দেশনা একটু সংক্ষিপ্ত করুন");String ts=String.join(",",TimeRules.times(times.getText().toString()));String raw=TimeRules.normalize(days.getText().toString());int count=raw.isEmpty()?0:Integer.parseInt(raw);if(count<0||count>3650||(!raw.isEmpty()&&count==0))throw new IllegalArgumentException("দিন ১ থেকে ৩৬৫০ দিন, অথবা ফাঁকা রাখুন");LocalDate start=LocalDate.now();String end=count==0?"":start.plusDays(count-1).toString();try(Store s=new Store(this)){if(s.meds().size()>=100)throw new IllegalArgumentException("সর্বোচ্চ ১০০টি ওষুধ রাখা যাবে");s.add(n,a,ts,start.toString(),end,nt);}Scheduler.refresh(this);dialog.dismiss();page="today";render();if(!notifications()||!Scheduler.exact(this))new AlertDialog.Builder(this).setTitle("রিমাইন্ডারের অনুমতি দিন").setMessage("সংরক্ষণ হয়েছে। নোটিফিকেশন এবং সময়মতো অ্যালার্ম সেটআপ করুন।").setPositiveButton("সেটআপ",(aa,bb)->{page="setup";render();}).setNegativeButton("পরে",null).show();
   }catch(IllegalArgumentException ex){error.setText(ex instanceof NumberFormatException?"দিনের ঘরে একটি সংখ্যা দিন":ex.getMessage());}
  }));dialog.show();
 }
 @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);Scheduler.refresh(this);render();}
}
