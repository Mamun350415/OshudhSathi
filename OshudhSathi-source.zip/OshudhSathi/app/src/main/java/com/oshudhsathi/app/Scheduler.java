package com.oshudhsathi.app;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.Build;
import java.time.*;
final class Scheduler {
 static PendingIntent intent(Context c,long id,String action) {
  Intent i=new Intent(c,ReminderReceiver.class).setAction(action).setData(Uri.parse("sathi://dose/"+id+"/"+action)).putExtra("id",id);
  return PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
 }
 static boolean exact(Context c) {return Build.VERSION.SDK_INT<31||c.getSystemService(AlarmManager.class).canScheduleExactAlarms();}
 static void schedule(Context c,Store.Dose d) {
  AlarmManager a=c.getSystemService(AlarmManager.class);long at=Math.max(System.currentTimeMillis()+1000,d.notifyAt);PendingIntent pi=intent(c,d.id,"REMIND");
  try { if(exact(c)) a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); }
  catch(SecurityException e) { a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); }
 }
 static void cancel(Context c,long id) { c.getSystemService(AlarmManager.class).cancel(intent(c,id,"REMIND"));c.getSystemService(NotificationManager.class).cancel("dose:"+id,1); }
 static void refresh(Context c) {
  try(Store s=new Store(c)) {
   LocalDate today=LocalDate.now(); long now=System.currentTimeMillis();
   for(Store.Med m:s.meds()) for(String slot:m.times.split(",")) {
    LocalDate next=today;
    if(TimeRules.at(next,slot,ZoneId.systemDefault())<=now) next=next.plusDays(1);
    if(TimeRules.inRange(next,m.start,m.end)) s.ensure(m,next,slot);
   }
   for(Store.Dose d:s.pending()) {
    // Recompute wall clock alarms after clock/time-zone changes, preserving snooze offsets.
    long offset=d.notifyAt-d.due;long due=TimeRules.at(LocalDate.parse(d.day),d.slot,ZoneId.systemDefault());
    if(due!=d.due) { android.content.ContentValues v=new android.content.ContentValues();v.put("due",due);v.put("notify_at",due+offset);s.getWritableDatabase().update("doses",v,"id=?",new String[]{""+d.id});d.due=due;d.notifyAt=due+offset; }
    if(d.notifyAt>now) schedule(c,d);
   }
  }
 }
}
