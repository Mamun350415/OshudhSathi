package com.oshudhsathi.app;
import android.app.*;
import android.content.*;
import android.os.Build;
public final class ReminderReceiver extends BroadcastReceiver {
 static final String CHANNEL="medicine_reminders";
 static void channel(Context c) { NotificationChannel ch=new NotificationChannel(CHANNEL,"ওষুধের রিমাইন্ডার",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("আপনার নির্ধারিত ওষুধ খাওয়ার সময়");ch.enableVibration(true);c.getSystemService(NotificationManager.class).createNotificationChannel(ch); }
 public void onReceive(Context c,Intent i) {
  long id=i.getLongExtra("id",-1);String action=i.getAction();
  try(Store s=new Store(c)) {
   Store.Dose d=s.dose(id);if(d==null||!"pending".equals(d.status)||!s.active(d.med))return;
   if("TAKEN".equals(action)) {s.complete(id,"taken");Scheduler.cancel(c,id);return;}
   if("SNOOZE".equals(action)) {if(s.snooze(id,System.currentTimeMillis()+10*60*1000L)){Scheduler.cancel(c,id);Scheduler.schedule(c,s.dose(id));}return;}
   if(!"REMIND".equals(action))return;
   if(d.notifyAt>System.currentTimeMillis()+2000) {Scheduler.schedule(c,d);return;}
   channel(c); NotificationManager nm=c.getSystemService(NotificationManager.class);
   if(nm.areNotificationsEnabled() && (Build.VERSION.SDK_INT<33||c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED)) {
    PendingIntent open=PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(com.oshudhsathi.app.R.drawable.ic_notification).setContentTitle(d.name+" খাওয়ার সময়").setContentText(d.amount+(d.note.isEmpty()?"":" • "+d.note)).setStyle(new Notification.BigTextStyle().bigText(d.amount+"\nনির্ধারিত সময়: "+d.slot+"\n"+d.note)).setContentIntent(open).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER).setVisibility(Notification.VISIBILITY_PRIVATE)
     .addAction(new Notification.Action.Builder(null,"খেয়েছি",Scheduler.intent(c,id,"TAKEN")).build())
     .addAction(new Notification.Action.Builder(null,"১০ মিনিট পরে",Scheduler.intent(c,id,"SNOOZE")).build()).build();
    if(c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED || Build.VERSION.SDK_INT<33) nm.notify("dose:"+id,1,n);
   }
  }
  Scheduler.refresh(c);
 }
}
