package com.oshudhsathi.app;
import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import java.nio.charset.StandardCharsets;
import java.security.*;
final class SoundSettings {
 static final String DEFAULT_CHANNEL="medicine_reminders";
 static String channelId(Context c){return c.getSharedPreferences("sound",Context.MODE_PRIVATE).getString("channel",DEFAULT_CHANNEL);}
 static Uri selected(Context c){NotificationChannel ch=c.getSystemService(NotificationManager.class).getNotificationChannel(channelId(c));return ch==null?android.provider.Settings.System.DEFAULT_NOTIFICATION_URI:ch.getSound();}
 static AudioAttributes attributes(){return new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();}
 static String name(Context c){Uri u=selected(c);if(u==null)return "কোনো সাউন্ড নেই";try{Ringtone r=RingtoneManager.getRingtone(c,u);return r==null?"ফোনের ডিফল্ট সাউন্ড":r.getTitle(c);}catch(SecurityException e){return "ফোনের সাউন্ড";}}
 static boolean blocked(Context c){NotificationManager nm=c.getSystemService(NotificationManager.class);NotificationChannel ch=nm.getNotificationChannel(channelId(c));return !nm.areNotificationsEnabled()||(ch!=null&&ch.getImportance()==NotificationManager.IMPORTANCE_NONE);}
 static boolean save(Context c,Uri u){
  if(u==null||blocked(c))return false;
  // Only platform picker sound URIs; no arbitrary files or network sources.
  String scheme=u.getScheme();if(!"content".equals(scheme)&&!"android.resource".equals(scheme))return false;
  String id;try{byte[] hash=MessageDigest.getInstance("SHA-256").digest(u.toString().getBytes(StandardCharsets.UTF_8));StringBuilder h=new StringBuilder();for(byte b:hash)h.append(String.format(java.util.Locale.ROOT,"%02x",b&255));id="medicine_sound_"+h;}catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}
  NotificationManager nm=c.getSystemService(NotificationManager.class);
  NotificationChannel ch=new NotificationChannel(id,"ওষুধের রিমাইন্ডার",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("আপনার বেছে নেওয়া ফোনের সাউন্ড");ch.setSound(u,attributes());ch.enableVibration(true);nm.createNotificationChannel(ch);
  c.getSharedPreferences("sound",Context.MODE_PRIVATE).edit().putString("channel",id).apply();return true;
 }
}
