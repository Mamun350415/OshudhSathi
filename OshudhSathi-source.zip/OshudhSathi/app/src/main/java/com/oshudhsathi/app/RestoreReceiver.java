package com.oshudhsathi.app;
import android.content.*;
public final class RestoreReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i) { Scheduler.refresh(c); }
}
