import com.oshudhsathi.app.TimeRules;
import java.time.*;
import java.util.*;
public class TimeRulesTest {
 static int checks=0;
 static void ok(boolean b){checks++;if(!b)throw new AssertionError("check "+checks);}
 static void bad(String s){boolean rejected=false;try{TimeRules.times(s);}catch(IllegalArgumentException e){rejected=true;}ok(rejected);}
 public static void main(String[] args){
  ok(Arrays.equals(TimeRules.times("৮:০০, 22:05, 08:00"),new String[]{"08:00","22:05"}));
  ok(Arrays.equals(TimeRules.times("0:00,23:59"),new String[]{"00:00","23:59"}));
  for(String s:new String[]{"","24:00","12:60","-1:00","8:0","8:00,","8:00 AM","1:00,2:00,3:00,4:00,5:00,6:00,7:00,8:00,9:00"})bad(s);
  ZoneId z=ZoneId.of("Asia/Dhaka");LocalDate day=LocalDate.of(2026,10,5);
  ok(Instant.ofEpochMilli(TimeRules.at(day,"08:00",z)).equals(Instant.parse("2026-10-05T02:00:00Z")));
  ok(TimeRules.inRange(day,"2026-10-05","2026-10-05"));
  ok(!TimeRules.inRange(day.plusDays(1),"2026-10-05","2026-10-05"));
  ok(!TimeRules.inRange(day.minusDays(1),"2026-10-05",""));
  ok(TimeRules.inRange(day.plusYears(1),"2026-10-05",""));
  // DST: Java resolves the nonexistent spring-forward wall clock time safely.
  ok(Instant.ofEpochMilli(TimeRules.at(LocalDate.of(2026,3,8),"02:30",ZoneId.of("America/New_York"))).equals(Instant.parse("2026-03-08T07:30:00Z")));
  System.out.println(checks+" time validation / date-range / time-zone checks passed");
 }
}
